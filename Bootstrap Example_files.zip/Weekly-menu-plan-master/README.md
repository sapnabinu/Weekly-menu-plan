# Weekly-menu-plan
Helps to plan your menu for any no of days and create a grocery list for you
